export const environment = {
  production: true,
  baseURL: 'https://6343d9b4b9ab4243cad8bf9e.mockapi.io'
};
