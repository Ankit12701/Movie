export class User{
    id:number=0;
    name:String="";
    movie_name:String="";
    tickets:number=0;
    show:string="";
 };