export interface Movie{
    id:number;//=0
    movie_name:String ;//=''
    tickets:Array<number>;//=0
    shows:Array<string>;//=['Morning','Afternoon','Night']
    imageUrl:String;//=''
    description:string;
};