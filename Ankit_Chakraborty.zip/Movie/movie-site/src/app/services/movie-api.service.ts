import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Constant } from '../utilities/constants';
import { catchError, Observable, retry, throwError } from 'rxjs';
import { Movie } from '../utilities/movie';
import { User } from '../utilities/User';
@Injectable({
  providedIn: 'root'
})
export class MovieApiService {

  constructor(private httpClient: HttpClient) { }
  getAllMovieDetail(): Observable<Movie[]> {
    return this.httpClient
      .get<Movie[]>(Constant.getEndpoint.toString())
      .pipe(retry(1), catchError(this.handleError));
  }
  getAMovieDetail(id:number): Observable<Movie> {
    // console.log(`${Constant.getSpecificData}${id}`);
    return this.httpClient
      .get<Movie>(`${Constant.getSpecificData}${id}`)
      .pipe(retry(1), catchError(this.handleError));
  }
 
  updateAMovieDetail(movie:Movie,id:number): Observable<User>{
      const header = new HttpHeaders();
      header.set('Content-Type', 'application/json');
      return this.httpClient
        .put<User>(`${Constant.editEndPoint}${id}`, movie, { headers: header })
        .pipe(retry(1), catchError(this.handleError));
  }
  handleError(er: any) {
    return throwError(() => {
      console.log(er);
    });
  }
}
