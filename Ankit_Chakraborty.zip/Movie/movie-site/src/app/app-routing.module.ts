import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MovieCardComponent } from './component/movie-card/movie-card.component';
import { BookingComponent } from './component/booking/booking.component';
import { EditComponent } from './component/edit/edit.component';
import { GridComponent } from './component/grid/grid.component';
const routes: Routes = 
[
  { path: '', redirectTo: 'movie', pathMatch: 'full' },
  { path: 'movie', component: MovieCardComponent },
  { path: 'book/:id', component: BookingComponent },
  { path:'grid',component:GridComponent},
  {path:'edit/:id',component:EditComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
