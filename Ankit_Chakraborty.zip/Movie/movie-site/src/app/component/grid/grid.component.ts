import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/utilities/User';
@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit{
 
  user1:User[]=[];
  displayedColumns: string[] = ['id','name', 'movie name', 'ticket', 'show','edit button'];
  dataSource:User[] = [];

ngOnInit(){
  this.user1=JSON.parse(localStorage.getItem('bookings') || '[]')
  this.dataSource=this.user1;
}

}
  


