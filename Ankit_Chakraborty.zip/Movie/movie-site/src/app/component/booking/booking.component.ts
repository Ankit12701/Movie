import { Component, OnInit } from '@angular/core';
import { MovieApiService } from 'src/app/services/movie-api.service';
import { Movie } from 'src/app/utilities/movie';
import { ActivatedRoute, UrlSerializer } from '@angular/router';
import { Router } from '@angular/router';
import { User } from 'src/app/utilities/User';
import Swal from 'sweetalert2'
@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  allbookings:any=[];
  idx:number=0;
  show:string=""
  name:string=""
  MovieList:Movie[]=[]
  counter:number=0
  img:String=""
  bookings:User[]=[];
  constructor(
    private movieService:MovieApiService,
    private route: ActivatedRoute,
    private router:Router,) { }
  movie:Movie={
    "movie_name": "Baahubali 2:The Conclusion",
    "tickets": [
     10,
     11,
     12
    ],
    "shows": [
     "Morning",
     "Afternoon",
     "Night"
    ],
    "imageUrl": "https://i.pinimg.com/originals/14/38/6b/14386b32f16b74aac333e63d018741d2.jpg",
    "description": "The film is set in medieval India and follows the sibling rivalry between Amarendra Baahubali and Bhallaladeva; the latter conspires against the former and has him killed by Kattappa. Years later, Amarendra/'s son returns to avenge his death.",
    "id": 1
   };
  ngOnInit(): void {
   
    this.getAMovieDetail();
    this.getAllMovies();
  }
  fun(show:string){
    if(show=='Morning')
    this.idx=0;
    else if(show=='Afternoon')
    this.idx=1;
    else 
    this.idx=2;
  
}
  getAllMovies(): void {
    this.movieService.getAllMovieDetail()
    .subscribe(movies => this.MovieList = movies);
  }
  getAMovieDetail(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.movieService.getAMovieDetail(id)
    .subscribe(movie => this.movie = movie);
  }
  increaseValue(){
    this.counter=this.counter+1;
  }
  decreaseValue(){
    this.counter=this.counter-1;
  }
  decrease(id:number,ticket:number,index:number){
    this.movie.tickets[index]-=ticket;
    this.movieService.updateAMovieDetail(this.movie,id)
    .subscribe();
  }
  submitHandler(id:number,count:number,name:string,show:string,index:number){
    if(count==0)
    {
      Swal.fire({
        icon: 'error',
        title: 'please select valid number of tickets',
        showConfirmButton: false,
        timer: 1500
       })
      return;
    }else if(count>this.movie.tickets[index]){
      Swal.fire({
        icon: 'error',
        title: 'no of ticket excceded the limit',
        showConfirmButton: false,
        timer: 1500
       })
    }else if(name=="" || show==""){
      Swal.fire({
        icon: 'error',
        title: 'Please fill all required entries',
        showConfirmButton: false,
        timer: 1500
       })
    }else{
         this.decrease(id,count,index);
         let user= new User();
         user.id=Date.now();
         user.name=this.name;
         user.movie_name=this.MovieList[id-1].movie_name;
         user.tickets=count
         user.show=show;
         this.allbookings = JSON.parse(localStorage.getItem('bookings') || '[]')
         this.allbookings.push(user)
         localStorage.setItem('bookings', JSON.stringify(this.allbookings));
         Swal.fire({
          icon: 'success',
          title: 'Your Booking is successfull',
          showConfirmButton: false,
          timer: 1500
         })
         this.router.navigate(['/','grid']);
        }
  }
}
