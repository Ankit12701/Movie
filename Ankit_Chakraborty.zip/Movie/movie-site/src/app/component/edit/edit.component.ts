import { Component, OnInit } from '@angular/core';
import { MovieApiService } from 'src/app/services/movie-api.service';
import { Movie } from 'src/app/utilities/movie';
import { ActivatedRoute, UrlSerializer } from '@angular/router';
import { Router } from '@angular/router';
import { User } from 'src/app/utilities/User';
import Swal from 'sweetalert2'
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  
  index=0;
  id=0;
  user= new User();
  user1:User[]=[];
  movie_index=0;
  show_index=0;
  name:string="";
  counter:number=0;
  MovieList:Movie[]=[]
 
  constructor(
    private movieService:MovieApiService,
    private route: ActivatedRoute,
    private router:Router,) { }
  movie:Movie={
    "movie_name": "Baahubali 2:The Conclusion",
    "tickets": [
     10,
     11,
     12
    ],
    "shows": [
     "Morning",
     "Afternoon",
     "Night"
    ],
    "imageUrl": "https://i.pinimg.com/originals/14/38/6b/14386b32f16b74aac333e63d018741d2.jpg",
    "description": "The film is set in medieval India and follows the sibling rivalry between Amarendra Baahubali and Bhallaladeva; the latter conspires against the former and has him killed by Kattappa. Years later, Amarendra/'s son returns to avenge his death.",
    "id": 1
   };
  ngOnInit(): void {
    this.getBookingDetails();
    this.getAllMovies();
    
  }
  
  getAllMovies(): void {
    this.movieService.getAllMovieDetail()
    .subscribe(MovieList =>{
       this.MovieList = MovieList
       this.getIndexUsingMovieName();
       this.getIndexOfMovieShowTime();
       this.getAMovieDetail(this.movie_index+1);
    });
  }
  getBookingDetails(){
    this.id = Number(this.route.snapshot.paramMap.get('id'));
    this.user1=JSON.parse(localStorage.getItem('bookings') || '[]')
    for(let i=0;i<this.user1.length;i++)
    {
      if(this.id==this.user1[i].id)
      {
        this.user=this.user1[i];
        this.index=i;
      }
    }
  }
  getIndexUsingMovieName(){
    let movie=this.user.movie_name;
    for(let i=0;i<this.MovieList.length;i++)
    {
      if(this.MovieList[i].movie_name==movie){
         this.movie_index=i;
      }
    
    }
   
  }
  getIndexOfMovieShowTime(){
    if(this.user.show=='Morning')
    this.show_index=0;
    else if(this.user.show=='Afternoon')
    this.show_index=1;
    else 
    this.show_index=2;
  }
  getAMovieDetail(id:number): void {
    this.movieService.getAMovieDetail(id)
    .subscribe(m => {
      this.movie = m;
    });
   
  }
  increaseValue(){
    this.counter=this.counter+1;
  }
  decreaseValue(){
    this.counter=this.counter-1;
  }
  
  updateLocalStorage(){
    this.user1[this.index]=this.user;
    localStorage.removeItem("bookings");
    localStorage.setItem("bookings",JSON.stringify(this.user1));
  }
  updateAMovieDetail(){
    this.movieService.updateAMovieDetail(this.movie,this.movie.id)
    .subscribe();
  }
  decrease( ){
    this.movie.tickets[this.show_index]+=this.user.tickets;
    this.user.tickets=this.counter;
    this.movie.tickets[this.show_index]-=this.counter;
    this.updateAMovieDetail();
  }
  
  submitHandler(name:string,count:number){
    if(count==0)
    {
      Swal.fire({
        icon: 'error',
        title: 'please select valid number of tickets',
        showConfirmButton: false,
        timer: 1500
       })
    
      return;
    }else if(count>this.MovieList[this.movie_index].tickets[this.show_index]){
    
      Swal.fire({
        icon: 'error',
        title: 'no of ticket excceded the limit',
        showConfirmButton: false,
        timer: 1500
       })
    }else if(name==""){
      Swal.fire({
        icon: 'error',
        title: 'Please fill all required entries',
        showConfirmButton: false,
        timer: 1500
       })
      alert('Please fill all required entries')
    }else{
         this.user.name=name;
         this.decrease();
         this.updateLocalStorage();
         Swal.fire({
          icon: 'success',
          title: 'Congratulations! You have successfully edited your tickets.',
          showConfirmButton: false,
          timer: 1500
         })
         this.router.navigate(['/','movie'])  .then(nav => {
          console.log(nav); // true if navigation is successful
        }, err => {
          console.log(err) // when there's an error
        });;
        }
  }
}
