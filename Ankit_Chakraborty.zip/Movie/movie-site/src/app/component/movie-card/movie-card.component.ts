import { Component, OnInit } from '@angular/core';
import { MovieApiService } from 'src/app/services/movie-api.service';
import { Movie } from 'src/app/utilities/movie';
@Component({
  selector: 'app-movie-card',
  templateUrl: './movie-card.component.html',
  styleUrls: ['./movie-card.component.css']
})
export class MovieCardComponent implements OnInit {

  constructor(private movieService:MovieApiService) { }

  movies:Movie[]=[];
  ngOnInit(): void {
   
    this.getAllMovies();
  }
  getAllMovies(): void {
    this.movieService.getAllMovieDetail()
    .subscribe(movies => {
      this.movies = movies
    });
   
  }


}
